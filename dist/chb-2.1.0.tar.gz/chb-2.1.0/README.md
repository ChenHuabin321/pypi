# 1 说明
本代码包为chb常用小代码，学习pypi打包用。
# 2 模块说明
- dao.py：常用数据库连接
- log.py：日志器
- utils：常用小工具
# 使用说明
from chb import *